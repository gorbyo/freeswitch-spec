#!/bin/bash
ORIGDIR=`pwd`
TMPDIR=mongo-c-driver.$$

mkdir -p ../${TMPDIR}

cd ..
cp -a libmongoc ${TMPDIR}/mongo-c-driver-1.1.0
cd ${TMPDIR}
rm -rf mongo-c-driver-1.1.0/.git*
tar zcvf mongo-c-driver-1.1.0.tar.gz mongo-c-driver-1.1.0
mv mongo-c-driver-1.1.0.tar.gz ${ORIGDIR}/.
cd ${ORIGDIR}
rm -rf ../${TMPDIR}
